#### 📍 **Verificar se Atende:**

É o processo de **análise da viabilidade técnica** para novos clientes ou mudanças de endereço.

Envolve:

- Confirmar se o **endereço informado está dentro da área de cobertura da OTI - ONLINE TELECOM.IP**.
    
- Consultar a disponibilidade de **porta, sinal, estrutura e rede** na região.
    
- Verificar se há **capacidade técnica** para ativação ou transferência do serviço.
    

👉 Essa etapa deve ser feita **antes de qualquer agendamento técnico ou proposta comercial.**

---


